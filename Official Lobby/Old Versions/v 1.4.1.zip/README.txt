-------------------------------------------------------------
This code is protected by the DMCA Act of 1998
For more information Please visit Website 
http://en.wikipedia.org/wiki/Digital_Millennium_Copyright_Act
-------------------------------------------------------------
Boarder, Hide, and K Brizzle's Official Se7ensins Patch
Developed by K Brizzle
-------------------------------------------------------------
<<<Change Log>>>>
20.6.10 v. 1.4.1
	Fixed Infection Menu bug
	Added custom class names to menu
20.6.10 v. 1.4.0
	Fixed VIP item freezes
	Fixed Player Option Menu bugs
	Added instructions to the menus
	Added in hover stretch effect in menu
	Reworked infection menu
	Cleaned up menu string initialization
	Fixed copyright at the top of the screen
15.6.10 v. 1.3.1
	Fixed Player list bugs
	Added in future support for array intializing
15.6.10 v. 1.3.0
	Added Button Combo Checking
	Added to Infections menu
14.6.10 v. 1.2.2
	Fixed All PLayers Bug
	Added in Button Combo checking Beta
14.6.10 v. 1.2.1
	Fixed HUD Elements to correct sounds/icons
	cleaned up code
13.6.10 v. 1.2.0
	Added Player Submenu
		Added Unban
		Added Unverify
		Added UnVip
		Added Rape (Lock All+Leaderboars Reset)
	Bug Fixes
	Cleaned up code
8.6.10 v. 1.1.0
	Added Killstreak Menu
	Added Cursor Position Save
	Converted to TU6
2.6.10 v. 1.0.0
	Patch Started
------------------------------------------------------------
<<<Features>>>

 Infinite Ammo
 [VIP]God Mode 
 [VIP]Player Option Menu
	-Select individual players or All
	-[All]Verfiy
	-UnVerify
	-[All]Kick and Ban
	-Unban
	-[All]Promote to Vip
	-demote
	-Lock All + Leaderboard Reset
 Mod Menu
	-[VIP]Toggle Walking AC130
	-Toggle Cartoon Mode
	-Teleport
	-Unlock All
	-Recieve Accolades
	-Rank to 70
	-Vision Menu - change you current player vision
	-[VIP]killstreak Menu - pick and recieve any killstreak
	-Infection Menu - Choose infection package
	-Legit Stats
	-Moderate Stats
	-Insane Stats
	-Reset Stats
	-Customize Leaderboards - Customly change any leaderboard stat

[VIP] - VIP Players only
[All] - Can select all players when using this option
